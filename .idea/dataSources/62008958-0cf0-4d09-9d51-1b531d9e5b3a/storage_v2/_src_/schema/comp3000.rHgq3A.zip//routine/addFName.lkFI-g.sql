create
    definer = root@localhost procedure addFName(IN inMacAddress varchar(20), IN inFriendlyName varchar(50))
BEGIN

UPDATE tbldevice
SET friendlyName = inFriendlyName
WHERE macAddress=inMacAddress; 

END;

