create
    definer = root@localhost procedure selectAllNetworkID(IN inNetworkID int)
BEGIN
select * from tbldevice WHERE networkID = inNetworkID;
END;

