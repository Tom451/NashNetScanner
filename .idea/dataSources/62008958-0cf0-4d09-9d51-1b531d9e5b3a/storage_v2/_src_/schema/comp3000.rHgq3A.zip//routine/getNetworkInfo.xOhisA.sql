create
    definer = root@localhost procedure getNetworkInfo(IN inNetworkID int)
BEGIN
select * from tblnetwork WHERE networkID = inNetworkID;
END;

