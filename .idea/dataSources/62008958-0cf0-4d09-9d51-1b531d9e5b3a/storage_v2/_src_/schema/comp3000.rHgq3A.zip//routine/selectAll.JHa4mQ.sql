create
    definer = root@localhost procedure selectAll()
BEGIN
select * from tbldevice;
END;

