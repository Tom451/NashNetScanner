create
    definer = root@localhost procedure addLink(IN inDeviceMacAddress varchar(50), IN inNetworkMacAddress varchar(50))
BEGIN

set @localdeviceID = (select deviceID from tbldevice WHERE macAddress = inDeviceMacAddress);
set @localnetworkID = (select networkID from tblnetwork WHERE macAddress = inNetworkMacAddress);

INSERT INTO tblnetworkdevicelink(networkID, deviceID)
VALUES (@localnetworkID, @localdeviceID);


END;

