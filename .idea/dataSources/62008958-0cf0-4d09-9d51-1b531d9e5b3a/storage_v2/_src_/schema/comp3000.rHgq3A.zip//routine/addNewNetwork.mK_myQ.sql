create
    definer = root@localhost procedure addNewNetwork(IN inMacAddress varchar(50), IN inName varchar(50))
BEGIN

IF exists (SELECT * FROM tblnetwork WHERE macAddress = inMacAddress) = 0 then
INSERT INTO tblnetwork(macAddress, friendlyName)
VALUES (inMacAddress, inName);

END IF;

END;

