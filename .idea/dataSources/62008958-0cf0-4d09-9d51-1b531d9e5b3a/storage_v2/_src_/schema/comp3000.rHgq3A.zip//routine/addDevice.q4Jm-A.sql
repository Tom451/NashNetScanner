create
    definer = root@localhost procedure addDevice(IN indeviceIP varchar(20), IN inRTT int, IN inMacAddress varchar(20),
                                                 IN inName varchar(50), IN networkMacAddress varchar(50))
BEGIN

set @networkMacAddressSelect = (select networkID FROM tblnetwork where tblnetwork.macAddress = networkMacAddress);

-- If the device exists, AND has already been scanned on the current network then just set the new time. 
IF exists(SELECT * FROM tbldevice WHERE @networkMacAddressSelect = networkID and inMacAddress = macAddress) = 1 then 

UPDATE tbldevice 
SET 
    lastSeen = NOW(),
    RTT = inRTT,
    friendlyName = inName
    
WHERE
    networkID = @networkMacAddressSelect AND macAddress = inMacAddress;


else

INSERT INTO tbldevice(ipAddress, RTT, macAddress, friendlyName, lastSeen, networkID)
		VALUES (indeviceIP, inRTT, inMacAddress, inName, NOW(), @networkMacAddressSelect);
        
end if;

END;

