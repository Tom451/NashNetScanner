create
    definer = root@localhost procedure addLink(IN inDeviceID int, IN inScanID int)
BEGIN
INSERT INTO devicescan(DeviceID, ScanID)
		VALUES (inDeviceID,  inScanID);
END;

