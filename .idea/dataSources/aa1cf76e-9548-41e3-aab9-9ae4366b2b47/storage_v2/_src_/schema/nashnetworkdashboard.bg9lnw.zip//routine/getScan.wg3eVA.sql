create
    definer = root@localhost procedure getScan(IN inSessionID varchar(20))
BEGIN
SELECT * FROM scan WHERE sessionID = inSessionID;
END;

