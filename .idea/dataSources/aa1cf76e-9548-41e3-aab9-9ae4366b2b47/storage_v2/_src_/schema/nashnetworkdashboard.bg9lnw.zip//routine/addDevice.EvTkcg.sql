create
    definer = root@localhost procedure addDevice(IN indeviceIP blob, IN inRTT blob, IN inMacAddress blob,
                                                 IN inName blob, OUT outDeviceID int)
BEGIN

INSERT INTO device(deviceIP, deviceMacAddress, deviceName, deviceLastSeen)
		VALUES (indeviceIP,  inMacAddress, inName, NOW());
        
SELECT deviceID INTO outDeviceID FROM device where deviceMacAddress = inMacAddress;

END;

