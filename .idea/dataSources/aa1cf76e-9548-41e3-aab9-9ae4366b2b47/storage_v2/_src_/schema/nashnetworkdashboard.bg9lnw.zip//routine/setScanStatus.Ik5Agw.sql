create
    definer = root@localhost procedure setScanStatus(IN inScanStatus varchar(10), IN inScanID int)
BEGIN

UPDATE scan
SET 
    ScanStatus = inScanStatus
WHERE
    ScanID = inScanID;

END;

