create
    definer = root@localhost procedure getDevice(IN inMacAddress varchar(17))
BEGIN
SELECT * FROM device where deviceMacAddress = inMacAddress;
END;

