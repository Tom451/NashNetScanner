create
    definer = root@localhost procedure addDevice(IN indeviceIP varchar(20), IN inRTT int, IN inMacAddress varchar(20),
                                                 IN inName varchar(50), OUT outDeviceID int)
BEGIN
INSERT INTO device(deviceIP, deviceMacAddress, deviceName, deviceLastSeen)
		VALUES (indeviceIP,  inMacAddress, inName, NOW());
        
SELECT deviceID INTO outDeviceID FROM device where deviceMacAddress = inMacAddress;

END;

