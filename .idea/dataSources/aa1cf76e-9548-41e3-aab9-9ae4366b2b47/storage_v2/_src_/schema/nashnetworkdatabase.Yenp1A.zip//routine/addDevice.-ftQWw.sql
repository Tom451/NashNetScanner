create
    definer = root@localhost procedure addDevice(IN indeviceIP varchar(16), IN inRTT blob, IN inMacAddress varchar(20),
                                                 IN inName varchar(150), IN inScanID int)
BEGIN
/* Declare the deviceID */
DECLARE newDeviceID INT;


IF EXISTS(SELECT * FROM device WHERE deviceMacAddress = inMacAddress OR deviceIP = indeviceIP)
THEN 
	/* get the deviceID */   
	SELECT deviceID INTO newDeviceID FROM device where deviceMacAddress = inMacAddress AND deviceIP = indeviceIP;
	UPDATE device SET devicename = inName WHERE deviceMacAddress = inMacAddress;
    
	/* add scan link */
    IF NOT EXISTS(SELECT * FROM deviceScan WHERE ScanID = inScanID AND DeviceID = newDeviceID)
    THEN
		INSERT INTO deviceScan(ScanID, DeviceID) VALUES (inScanID, newDeviceID); 
    END IF;
ELSE

	/* Insert the device */
	INSERT INTO device(deviceIP, deviceMacAddress, deviceName, deviceLastSeen)
			VALUES (indeviceIP,  inMacAddress, inName, NOW());
	/* get the deviceID */   
	SELECT deviceID INTO newDeviceID FROM device where deviceMacAddress = inMacAddress AND deviceIP = indeviceIP;
	/* add scan link */  
	IF NOT EXISTS(SELECT * FROM deviceScan WHERE ScanID = inScanID AND DeviceID = newDeviceID)
    THEN
		INSERT INTO deviceScan(ScanID, DeviceID) VALUES (inScanID, newDeviceID); 
    END IF;

end if;

END;

