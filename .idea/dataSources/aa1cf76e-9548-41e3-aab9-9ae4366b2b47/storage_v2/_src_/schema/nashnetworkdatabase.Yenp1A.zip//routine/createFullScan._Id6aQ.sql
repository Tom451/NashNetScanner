create
    definer = root@localhost procedure createFullScan(IN inUserID int, IN inSessionID varchar(50),
                                                      IN inScanInfo varchar(100), IN inScanType varchar(15),
                                                      IN inScanStatus varchar(15), IN inScanTime datetime,
                                                      IN inDeviceID int)
BEGIN
/* Declare the deviceID */
DECLARE newScanID INT;

/* Insert the device */
	INSERT INTO scan(SessionID, userID, ScanInfo, ScanType, ScanStatus, ScanTime)
			VALUES (inSessionID,  inUserID, inScanInfo, inScanType, inScanStatus, inScanTime);
	/* get the deviceID */   
	SELECT last_insert_id() into newScanID;
    
    IF NOT EXISTS(SELECT * FROM deviceScan WHERE ScanID = newScanID)
    THEN
		INSERT INTO deviceScan(ScanID, DeviceID) VALUES (newScanID, inDeviceID); 
    END IF;

END;

