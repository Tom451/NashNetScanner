create
    definer = root@localhost procedure createScan(IN inUserID int, IN inSessionID varchar(50),
                                                  IN inScanInfo varchar(100), IN inScanType varchar(15),
                                                  IN inScanStatus varchar(15), IN inScanTime datetime)
BEGIN
/* Declare the deviceID */
DECLARE newScanID INT;

IF NOT EXISTS(SELECT * FROM scan WHERE SessionID = inSessionID)
THEN
/* Insert the device */
	INSERT INTO scan(SessionID, userID, ScanInfo, ScanType, ScanStatus, ScanTime)
			VALUES (inSessionID,  inUserID, inScanInfo, inScanType, inScanStatus, inScanTime);
	/* get the deviceID */   
	SELECT ScanID INTO newScanID FROM scan where SessionID = inSessionID;
    
    IF NOT EXISTS(SELECT * FROM deviceScan WHERE ScanID = newScanID)
    THEN
		INSERT INTO deviceScan(ScanID, DeviceID) VALUES (inScanID, newDeviceID); 
    END IF;

ELSE
SELECT * FROM scan;

END IF;
END;

