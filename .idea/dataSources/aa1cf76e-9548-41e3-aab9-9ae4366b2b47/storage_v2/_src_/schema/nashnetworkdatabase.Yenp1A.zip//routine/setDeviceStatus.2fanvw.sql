create
    definer = root@localhost procedure setDeviceStatus(IN inMacAddress blob, IN inIPAddress blob,
                                                       IN indeviceScanned varchar(20))
BEGIN

if(inMacAddress != "Null") THEN
/* add scan link */  
UPDATE
    device
SET 
    deviceScanned = indeviceScanned
    
WHERE deviceMacAddress = inMacAddress;
ELSE

UPDATE
    device
SET 
    deviceScanned = indeviceScanned
    
WHERE deviceIP = inIPAddress;

END IF;
END;

