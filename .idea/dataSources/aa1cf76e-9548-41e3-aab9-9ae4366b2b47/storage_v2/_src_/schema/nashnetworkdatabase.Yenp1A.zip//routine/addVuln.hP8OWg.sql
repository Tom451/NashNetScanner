create
    definer = root@localhost procedure addVuln(IN inScanID int, IN inVulnName varchar(30), IN inVulnVersion varchar(30),
                                               IN inVulnExtraData varchar(45), IN inVulnProduct varchar(45),
                                               IN inPortNumber varchar(45), IN inVulnCPE varchar(100))
BEGIN

/* Declare the vulnID */
DECLARE newVulnID INT;

IF EXISTS(SELECT * FROM vulnerabilities WHERE inVulnName = VulnName AND inVulnProduct = VulnProduct AND inVulnVersion = VulnVersion AND inPortNumber = VulnPortNumber)
THEN 
/* get the vulnID */   
SELECT VulnID INTO newVulnID FROM vulnerabilities where VulnName = inVulnName AND VulnProduct = inVulnProduct AND  VulnVersion = inVulnVersion AND VulnPortNumber = inPortNumber ;

/* add scan link */  
INSERT INTO vulnscan(VulnID, ScanID) VALUES (newVulnID, inScanID);

ELSE

/* Insert the device */
INSERT INTO vulnerabilities(VulnName, VulnVersion, VulnExtraData, VulnProduct, VulnPortNumber, VulnCPE)
		VALUES (inVulnName,  inVulnVersion,  inVulnExtraData, inVulnProduct, inPortNumber, inVulnCPE);
        
/* get the vulnID */   
SELECT VulnID INTO newVulnID FROM vulnerabilities where VulnName = inVulnName AND VulnProduct = inVulnProduct AND VulnVersion = inVulnVersion AND VulnPortNumber = inPortNumber;
   
/* add scan link */  
INSERT INTO vulnscan(VulnID, ScanID) VALUES (newVulnID, inScanID);

END IF;
END;

