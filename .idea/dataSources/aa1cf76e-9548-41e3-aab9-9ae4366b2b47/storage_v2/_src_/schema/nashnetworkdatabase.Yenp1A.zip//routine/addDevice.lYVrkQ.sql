create
    definer = root@localhost procedure addDevice(IN indeviceIP blob, IN inRTT blob, IN inMacAddress blob,
                                                 IN inName blob, IN inScanID int)
BEGIN

/* Declare the deviceID */
DECLARE newDeviceID INT;

IF EXISTS(SELECT * FROM device WHERE deviceMacAddress = inMacAddress)
THEN 
/* get the deviceID */   
SELECT deviceID INTO newDeviceID FROM device where deviceMacAddress = inMacAddress AND deviceIP = indeviceIP;

/* add scan link */  
INSERT INTO deviceScan(ScanID, DeviceID) VALUES (inScanID, newDeviceID);

ELSE

/* Insert the device */
INSERT INTO device(deviceIP, deviceMacAddress, deviceName, deviceLastSeen)
		VALUES (indeviceIP,  inMacAddress, inName, NOW());
        
/* get the deviceID */   
SELECT deviceID INTO newDeviceID FROM device where deviceMacAddress = inMacAddress AND deviceIP = indeviceIP;
   
/* add scan link */  
INSERT INTO deviceScan(ScanID, DeviceID) VALUES (inScanID, newDeviceID);

end if;

END;

